from odoo import models, fields, api, _


class JobCost(models.Model):
    _name = "job.costing"
    _description = "Job Costing"
    _inherit = ['mail.thread', 'mail.activity.mixin']

    @api.model
    def create(self, vals):
        if vals.get('name', _('New')) == _('New'):
            vals['name'] = self.env['ir.sequence'].next_by_code('joborder.sequence') or _('New')
        result = super(JobCost, self).create(vals)
        return result

    title = fields.Char(string='Title', required="1")
    name = fields.Char(string='Sequence', required=True, copy=False, readonly=True,
                           index=True, default=lambda self: _('New'))
    project = fields.Many2one('project.project', string="Project")
    assigned = fields.Many2one('hr.employee', string="Assigned To")
    start_date = fields.Datetime(string="Start Date")
    user_id = fields.Many2one('res.users', string='Created By', default=lambda self: self.env.user)
    end_date = fields.Datetime(string="End Date")
    order_lines = fields.One2many('job.order.lines', 'order_id', string="Order Lines")
    priority = fields.Selection(
        [('0', 'Normal'), ('1', 'Urgent')], 'Priority', default='0', index=True)
    deadline_date = fields.Datetime(string="Deadline Date")
    planned_hours = fields.Float(string="Initial Planned Hours")
    tags = fields.Many2many('project.tags',string="Tags")


class JobOrderLines(models.Model):
    _name = "job.order.lines"
    _description = "Job Order Line"

    def view_job_cost(self):
        print("button clicked")
        #action = self.env.ref('my_second_module.job_cost').read()[0]
        return {
            'type': 'ir.actions.act_window',
            'name': 'Job Cost Sheet',
            'res_model': 'job.cost',
            'view_type': 'form',
            'domain': [('title', '=', self.title), ('project.id', '=', self.project.id)],
            'view_mode': 'tree,form',
            'target': 'current'
        }

    title = fields.Char(string="Scope of Work")
    name = fields.Char(string="name", related="title")
    serial_no = fields.Integer(string="S/N")
    description = fields.Char(string="Description")
    quantity = fields.Integer(string="Quantity")
    project = fields.Many2one('project.project', string="Project")
    display_type = fields.Selection([
        ('line_section', "Section"),
        ('line_note', "Note")], default=False)
    order_id = fields.Many2one('job.costing', string="Order ID")


class JobCostSheet(models.Model):
    _name = "job.cost"
    _description = "Job Cost Sheet"
    _inherit = ['mail.thread', 'mail.activity.mixin']

    @api.model
    def create(self, vals):
        if vals.get('name', _('New')) == _('New'):
            vals['name'] = self.env['ir.sequence'].next_by_code('jobcost.sequence') or _('New')
        result = super(JobCostSheet, self).create(vals)
        return result

    title = fields.Many2one('job.order.lines', string="Title")
    name = fields.Char(string='Sequence', required=True, copy=False, readonly=True,
                           index=True, default=lambda self: _('New'))
    project = fields.Many2one('project.project', string="Project")
    job_order = fields.Many2one('job.costing', string="Job Order")
    analytic_acct = fields.Many2one("account.analytic.account", string="Analytic Account")
    user_id = fields.Many2one('res.users', string='Created By', default=lambda self: self.env.user)
    total_amt = fields.Integer(compute="_total_all", string="Total")
    mat_lines = fields.One2many('material.cost', 'mat_id', string="Material Lines")
    lab_lines = fields.One2many('labour.cost', 'lab_id', string="Labour Lines")
    equip_lines = fields.One2many('equipment.cost', 'equip_id', string="Equipment Lines")
    overhead_lines = fields.One2many('overhead.cost', 'overhead_id', string="Equipment Lines")

    @api.depends('mat_lines.amount')
    def _total_all(self):
        for order in self:
            total_amt = 0.0
            for line in order.mat_lines:
                total_amt += line.amount


class Material(models.Model):
    _name = "material.cost"

    product = fields.Many2one('product.product', string="Material")
    uom = fields.Many2one('uom.uom', string="Unit of Measure")
    description = fields.Char(string="Description")
    unit_price = fields.Monetary(string="Unit Price")
    quantity = fields.Integer(string="Quantity")
    currency_id = fields.Many2one('res.currency', 'Currency', required=True,
                                  default=lambda self: self.env.company.currency_id.id)
    amount = fields.Monetary(compute="_total_amount", string="Amount")
    display_type = fields.Selection([
        ('line_section', "Section"),
        ('line_note', "Note")], default=False)
    mat_id = fields.Many2one('job.cost', string="Order ID")

    @api.depends('quantity', 'unit_price')
    def _total_amount(self):
        for rec in self:
            rec.amount = rec.quantity * rec.unit_price


class Labour(models.Model):
    _name = "labour.cost"

    employee = fields.Many2one('hr.employee', string="Employee")
    dept = fields.Many2one('hr.department', string="Department")
    job = fields.Many2one('hr.job', string="Job Position")
    currency_id = fields.Many2one('res.currency', 'Currency', required=True,
                                  default=lambda self: self.env.company.currency_id.id)
    cost_day = fields.Monetary(string="Rate")
    estimated_cost = fields.Monetary(compute='_estimated_cost', string="Total")
    estimated_days = fields.Integer(string="No of Days")
    display_type = fields.Selection([
        ('line_section', "Section"),
        ('line_note', "Note")], default=False)
    lab_id = fields.Many2one('job.cost', string="Order ID")

    @api.depends('cost_day', 'estimated_days')
    def _estimated_cost(self):
        for rec in self:
            rec.estimated_cost = rec.estimated_days * rec.cost_day


class Equipment(models.Model):
    _name = "equipment.cost"

    equipment = fields.Many2one('maintenance.equipment', string="Equipment")
    equip_category = fields.Many2one('maintenance.equipment.category', string="Equipment Category")
    currency_id = fields.Many2one('res.currency', 'Currency', required=True,
                                  default=lambda self: self.env.company.currency_id.id)
    cost_day = fields.Monetary(string="Rate")
    estimated_cost = fields.Monetary(compute='_estimated_amount', string="Total")
    estimated_days = fields.Integer(string="No of Days")
    display_type = fields.Selection([
        ('line_section', "Section"),
        ('line_note', "Note")], default=False)
    equip_id = fields.Many2one('job.cost', string="Order ID")

    @api.depends('cost_day', 'estimated_days')
    def _estimated_amount(self):
        for rec in self:
            rec.estimated_cost = rec.cost_day * rec.estimated_days


class Overhead(models.Model):
    _name = "overhead.cost"

    expense = fields.Char(string="Expense")
    currency_id = fields.Many2one('res.currency', 'Currency', required=True,
                                  default=lambda self: self.env.company.currency_id.id)
    unit_price = fields.Monetary(string="Unit Price")
    estimated_cost = fields.Monetary(string="Total", compute="_estimated_amount")
    quantity = fields.Integer(string="Quantity")
    display_type = fields.Selection([
        ('line_section', "Section"),
        ('line_note', "Note")], default=False)
    overhead_id = fields.Many2one('job.cost', string="Order ID")

    @api.depends('unit_price', 'quantity')
    def _estimated_amount(self):
        for rec in self:
            rec.estimated_cost = rec.unit_price * rec.quantity





