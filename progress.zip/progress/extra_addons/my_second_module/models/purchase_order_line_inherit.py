from odoo import models, fields, api, _


class PurchaseOrderLineInherit(models.Model):
    _inherit = "purchase.order.line"

    order_id = fields.Many2one('purchase.order', string='Order Reference', index=True, required=False,
                               ondelete='cascade')


