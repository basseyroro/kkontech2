from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError
from datetime import datetime, timedelta


class MaterialRequisition(models.Model):
    _name = "material.requisition"
    _description = "Material Requisition"
    _rec_name = 'name'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    def dept_mana(self):
        self.write({'state': 'invent_mana', 'dept_mana_approval': self.env.user, 'dept_mana_date': fields.Datetime.now()})

    def invent_mana(self):
        self.write(
            {'state': 'approved', 'inventory_approval': self.env.user, 'invent_mana_date': fields.Datetime.now()
             })

    def received(self):
        if self.employee.user_id != self.env.user | self.req_responsible.user_id != self.env.user:
            raise UserError(_("You cannot receive this as you are not the owner of this document"))
        self.write({'state': 'done'})

    def cancel(self):
        self.write({'state': 'cancel'})

    def confirm_requisition(self):
        self.write({'state': 'dept_mana'})

    def action_reset_draft(self):
        self.write({'state': 'draft'})

    def create_picking_po(self):
        purchase_order_obj = self.env['purchase.order']
        purchase_order_line_obj = self.env['purchase.order.line']
        for requisition in self:
            for line in requisition.requisition_lines:
                if line.requisition_action == 'internal_picking':
                    raise models.ValidationError('Please Change Requisition Action to Purchase Order')
                elif line.requisition_action == 'purchase_order':
                    for vendor in line.vendor_id:
                        pur_order = purchase_order_obj.search([('requisition_po_id','=',requisition.id),('partner_id','=',vendor.id)])
                        if pur_order:
                            po_line_vals = {
                                'product_id': line.product.id,
                                'product_qty': line.qty,
                                'name': line.description,
                                'price_unit': line.product.list_price,
                                'date_planned': datetime.now(),
                                'product_uom': line.uom.id,
                                'order_id': pur_order.id,
                            }
                            purchase_order_line = purchase_order_line_obj.create(po_line_vals)
                            return purchase_order_line
                        else:
                            vals = {
                                'partner_id': vendor.id,
                                'date_order': datetime.now(),
                                'requisition_po_id': requisition.id,
                                'origin': requisition.name,
                                'state': 'draft',
                                'picking_type_id': requisition.picking_type_id.id
                            }
                            purchase_order = purchase_order_obj.create(vals)
                            po_line_vals = {
                                'product_id': line.product.id,
                                'product_qty': line.qty,
                                'name': line.description,
                                'price_unit': line.product.list_price,
                                'date_planned': datetime.now(),
                                'product_uom': line.uom.id,
                                'order_id': purchase_order.id,
                            }
                            purchase_order_line = purchase_order_line_obj.create(po_line_vals)
                            return purchase_order_line

    def int_trans_action(self):
        pass

    @api.model
    def create(self, vals):
        if vals.get('name', 'New') == 'New':
            vessel = vals.get('vessel', False)
            requisition_type = vals.get('requisition_type', False)
            if requisition_type == 'request_stores':
                if vessel == 'vessel_a':
                    vals['name'] = self.env['ir.sequence'].next_by_code('vessela.sequence')
                elif vessel == 'vessel_b':
                    vals['name'] = self.env['ir.sequence'].next_by_code('vesselb.sequence')
            else:
                vals['name'] = self.env['ir.sequence'].next_by_code('internal.sequence')
        return super(MaterialRequisition, self).create(vals)

    employee = fields.Many2one('hr.employee', string="Employee")
    department = fields.Many2one('hr.department', string="Department", related="employee.department_id")
    req_responsible = fields.Many2one('res.users', string="Requisition Responsible")
    currency = fields.Many2one('res.currency', string="Currency")
    requisition_date = fields.Datetime(string="Request Date")
    received_date = fields.Date(string="Received Date")
    requisition_deadline_date = fields.Date(string="Requisition Deadline")
    requisition_lines = fields.One2many('requisition.lines', 'req_id', string="Requisition Lines")
    company = fields.Many2one('res.company', string="Company")
    confirm_by = fields.Many2one('res.users', string="Confirm By:")
    dept_mana_approval = fields.Many2one('res.users', string="Approved By Departmental Manager:")
    inventory_approval = fields.Many2one('res.users', string="Approved By Inventory Manager:")
    rejected_by = fields.Many2one('res.users', string="Rejected By:")
    invent_mana_date = fields.Datetime(string="Inventory Manager Approval Date")
    rejected_date = fields.Datetime(string="Rejected Date:")
    confirmed_date = fields.Datetime(string="Confirmed Date")
    dept_mana_date = fields.Datetime(string="Department Manager Approval Date")
    received_approval = fields.Many2one('res.users', string="Received By:")
    equip_maint = fields.Many2one('maintenance.equipment', string="Equipment")
    receive_date = fields.Datetime(string="Received Date:")
    reason_for_requisition = fields.Char(string="Reason for Requisition")
    place = fields.Char(string="Place")
    ref = fields.Char(string="Ref")
    picking_type_id = fields.Many2one('stock.picking.type', string="Picking Type", domain=[('code', '=', 'incoming')])
    internal_picking_id = fields.Many2one('stock.picking.type', string="Internal Picking Type",
                                          domain=[('code', '=', 'internal')])
    source_location_id = fields.Many2one('stock.location', string="Source Location")
    destination_location_id = fields.Many2one('stock.location', string="Destination Location")
    use_manual_locations = fields.Many2one('stock.location', string="Manual Location")
    partner_id = fields.Many2one('res.partner', string="Vendor")
    urgent = fields.Boolean(string='Urgent:', default=False)
    routine = fields.Boolean(string='Routine:', default=False)
    elect = fields.Boolean(string='Mechanical&Electrical', default=False)
    priority = fields.Selection(
        [('0', 'Normal'), ('1', 'Routine'), ('2', 'Urgent'), ('3', 'Highly Urgent')], 'Priority',
        default='0', index=True)
    requisition_action_1 = fields.Selection([
        ('purchase_order', 'Purchase Order'),
        ('internal_picking', 'Internal Transfer')
    ], string='Requisition Action', related="requisition_lines.requisition_action")
    requisition_type = fields.Selection([
        ('request_stores', 'Consumables'),
        ('request_spare', 'Requisition Spare Parts')], string='Requisition Type')
    requisition_type_1 = fields.Selection([
        ('request_stores', 'Consumables'),
        ('request_spare', 'Requisition Spare Parts')], string='Requisition Type1', related="requisition_type")
    vessel = fields.Selection([
        ('vessel_a', 'Vessel A'),
        ('vessel_b', 'Vessel B')], string='Vessel')
    vess_le = fields.Selection([
        ('vessel_a', 'Vessel A'),
        ('vessel_b', 'Vessel B')], string='Vessel', related="vessel")
    name = fields.Char(string='Request Reference', required=True, copy=False, readonly=True, index=True,
                       default=lambda self: _('New'))
    state = fields.Selection([
        ('draft', 'Draft'),
        ('dept_mana', 'Department Head Approval'),
        ('invent_mana', 'Inventory Manager Approval'),
        ('approved', 'Approved'),
        ('done', 'Done'),
        ('cancel', 'Rejected')
    ], string='Status', readonly=True, index=True, copy=False, default='draft', tracking=True)


class RequisitionLines(models.Model):
    _name = "requisition.lines"
    _description = "Requisition Lines"

    product = fields.Many2one('product.product', string="Product", required=True)
    description = fields.Text(string="Description")
    qty = fields.Float(string="Quantity")
    vendor_id = fields.Many2one('res.partner', string="Vendor")
    code = fields.Integer(string="Code")
    rob = fields.Integer(string="ROB")
    uom = fields.Many2one('uom.uom', string="Unit Of Measure")
    status = fields.Selection([
        ('draft', 'Draft'),
        ('dept_mana', 'Department Head Approval'),
        ('invent_mana', 'Inventory Manager Approval'),
        ('approved', 'Approved'),
        ('done', 'Done'),
        ('cancel', 'Rejected')
    ], string='State', readonly=True, related="req_id.state")
    requisition_action = fields.Selection([
        ('purchase_order', 'Purchase Order'),
        ('internal_picking', 'Internal Transfer')
    ], string='Requisition Action', required=True)
    req_id = fields.Many2one('material.requisition', string="Request Id")


class PurchaseOrder(models.Model):
    _inherit = 'purchase.order'

    requisition_po_id = fields.Many2one('material.requisition', string="Purchase Requisition")


class StockPicking(models.Model):
    _inherit = 'stock.picking'

    requisition_picking_id = fields.Many2one('material.requisition', string="Purchase Requisition")


