from odoo import models, fields, api, _


class ExpenseCustom(models.Model):
    _inherit = "maintenance.request"

    def _total_amount(self):
        for rec in self:
            spare = sum(line.amount for line in rec.spareparts_lines)
            expense = sum(line.amount for line in rec.expense_lines)
            rec.cost = spare + expense

    @api.model
    def read_group(self, domain, fields, groupby, offset=0, limit=None, orderby=False, lazy=True):
        res = super(ExpenseCustom, self).read_group(domain, fields, groupby, offset=offset, limit=limit, orderby=orderby
                                                    , lazy=lazy)
        if 'cost' in fields:
            for line in res:
                if '__domain' in line:
                    lines = self.search(line['__domain'])
                    cost = 0.0
                    for record in lines:
                        cost += record.cost
                    line['cost'] = cost
        return res

    spareparts_lines = fields.One2many('spareparts.lines', 'spare_id', string="Spare Part Lines")
    expense_lines = fields.One2many('otherexpenses.lines', 'expense_id', string="Other Expense Lines")
    currency_id = fields.Many2one('res.currency', 'Currency', required=True, default=lambda self: self.env.company.currency_id.id)
    cost = fields.Monetary(string="Maintenance Cost", compute="_total_amount", group_operator='sum')
    vessel = fields.Many2one('stock.warehouse', string="Vessel")
    location = fields.Many2one('stock.location', string="Location", domain="[('usage', '=', 'internal')]")
    request_id = fields.Many2one('material.requisition', string='Store Request')

    @api.onchange('request_id')
    def _onchange_request_id(self):
        for rec in self:
            lines = [(5, 0, 0)]
            for line in self.request_id.requisition_lines:
                vals = {
                    'product': line.product,
                    'quantity': line.qty
                }
                lines.append((0, 0, vals))
            rec.spareparts_lines = lines


class SparepartsLines(models.Model):
    _name = "spareparts.lines"
    _description = "Spare Parts Lines"

    product = fields.Many2one('product.product', string="Spare Part", domain="[('categ_id', '=', 'All / Spare')]")
    manufacturer = fields.Char(string="Manufacturer")
    serial_no = fields.Char(string="Serial Number")
    quantity = fields.Integer(string="Quantity")
    currency_id = fields.Many2one('res.currency', 'Currency', required=True, default=lambda self: self.env.company.currency_id.id)
    unit_price = fields.Monetary(string="Unit Price")
    amount = fields.Monetary(compute="_total_amount", string="Amount")
    spare_id = fields.Many2one('maintenance.request', string="Spare Parts Id")

    @api.depends('quantity', 'unit_price')
    def _total_amount(self):
        for rec in self:
            rec.amount = rec.quantity * rec.unit_price


class OtherExpenses(models.Model):
    _name = "otherexpenses.lines"
    _description = "Other Expenses Lines"

    description = fields.Char(string="Expense Description")
    currency_id = fields.Many2one('res.currency', 'Currency', required=True, default=lambda self: self.env.company.currency_id.id)
    amount = fields.Monetary(string="Amount")
    expense_id = fields.Many2one('maintenance.request', string="Expense Id")

