import math
from odoo import models, fields, api, _
from datetime import date, datetime, timedelta


class EquipmentCustom(models.Model):
    _inherit = "maintenance.equipment"

    def _create_new_request_new(self, date):
        self.ensure_one()
        self.env['maintenance.request'].create({
            'name': _('Preventive Maintenance - %s', self.name),
            'request_date': date,
            'schedule_date': date,
            'category_id': self.category_id.id,
            'equipment_id': self.id,
            'maintenance_type': 'preventive',
            'owner_user_id': self.owner_user_id.id,
            'user_id': self.technician_user_id.id,
            'maintenance_team_id': self.maintenance_team_id.id,
            'duration': self.maintenance_duration,
            'company_id': self.company_id.id or self.env.company.id
            })

    @api.model
    def _cron_generate_requests_new(self):
        """
            Generates maintenance request on the next_action_date or today if none exists
        """
        for equipment in self.search([('deter', '=', 1)]):
            next_requests = self.env['maintenance.request'].search([('stage_id.done', '=', False),
                                                                    ('equipment_id', '=', equipment.id),
                                                                    ('maintenance_type', '=', 'preventive'),
                                                                    ('request_date', '=',
                                                                     fields.Datetime.now())])
            if not next_requests:
                equipment._create_new_request_new(equipment.next_action_date)

    def _check(self):
        if self.diff % self.period_mile == 0:
            self.deter = 1
        else:
            self.deter = 0

    def write(self,vals):
        a = self.final_val
        print(a)
        rtn = super(EquipmentCustom, self).write(vals)
        print("Values ...", vals)
        c = vals
        b = c.get('final_val')
        print(type(b))
        try:
            self.diff = b - a
        except:
            print(self.diff)
        return rtn

    period_mile = fields.Float('Mileage between each preventive maintenance', default=1)
    final_val = fields.Float(string="Final Reading")
    deter = fields.Integer(compute="_check", string="Factor")
    diff = fields.Integer(string="Difference")
    check = fields.Boolean(String="Check", default=False)
    request_date = fields.Datetime(string="Request Date")







