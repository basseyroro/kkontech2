from odoo import models, fields, api, _

class SalesCustom(models.Model):
    _inherit = 'sales.order'


