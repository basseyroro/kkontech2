import datetime
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT as DF
from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError, Warning


class ImprestHandler(models.Model):
    _name = "imprest.handler"
    _rec_name = 'name_seq'

    def _total_all(self):
        for rec in self:
            rec.total_amt = sum(line.amount for line in rec.imprest_ids)

    @api.model
    def create(self, vals):
        if vals.get('name_seq', _('New')) == _('New'):
            vals['name_seq'] = self.env['ir.sequence'].next_by_code('imprest.sequence') or _('New')
        result = super(ImprestHandler, self).create(vals)
        return result

    @api.model
    def read_group(self, domain, fields, groupby, offset=0, limit=None, orderby=False, lazy=True):
        res = super(ImprestHandler, self).read_group(domain, fields, groupby, offset=offset, limit=limit, orderby=orderby
                                                    , lazy=lazy)
        if 'total_amt' in fields:
            for line in res:
                if '__domain' in line:
                    lines = self.search(line['__domain'])
                    total_amt = 0.0
                    for record in lines:
                        total_amt += record.total_amt
                    line['total_amt'] = total_amt
        return res

    @api.constrains('amount_given')
    def check_balance(self):
        for rec in self:
            rec.total_amt = sum(line.amount for line in rec.imprest_ids)
            amt_giv = rec.amount_given
            tot_amt = rec.total_amt
            bal = amt_giv - tot_amt
            print(bal)
            if bal < 0:
                raise models.ValidationError('Balance can not be negative')
            elif bal == 0:
                return {self.write(
                    {'state': 'done', 'warn_ing': True, 'end_date': fields.Datetime.now()
                     })}

    @api.depends("total_amt")
    def _balance_check(self):
        self.balance = self.amount_given - self.total_amt
        if self.balance < 0:
            raise models.ValidationError('Balance can not be negative')
        for rec in self:
            if rec.balance >= 0.0:
                rec.balance_tree = rec.balance

    @api.depends('imprest_ids.amount')
    def action_progress(self):
        self.write({'state': 'in_progress'})

    @api.onchange('start_date')
    def change_date_field_year(self):
        self.year = fields.Date.from_string(self.start_date).strftime('%Y')

    @api.onchange('start_date')
    def change_date_field(self):
        self.month = fields.Date.from_string(self.start_date).strftime('%m')
        if self.month == '01':
            self.month = 'January'
        elif self.month == '02':
            self.month = 'Feburary'
        elif self.month == '03':
            self.month = 'March'
        elif self.month == '04':
            self.month = 'April'
        elif self.month == '05':
            self.month = 'May'
        elif self.month == '06':
            self.month = 'June'
        elif self.month == '07':
            self.month = 'July'
        elif self.month == '08':
            self.month = 'August'
        elif self.month == '09':
            self.month = 'September'
        elif self.month == '10':
            self.month = 'October'
        elif self.month == '11':
            self.month = 'November'
        else:
            self.month = 'December'

    balance = fields.Monetary(compute="_balance_check", string="Balance")
    bal = fields.Integer(string="bal")
    balance_tree = fields.Monetary(string="Balance")
    created_by = fields.Many2one('hr.employee', string="Created By")
    total_amt = fields.Monetary(compute="_total_all", string="Amount Spent")
    amount_given = fields.Monetary(string="Amount Given")
    name_seq = fields.Char(string='Report Reference', required=True, copy=False, readonly=True,
                           index=True, default=lambda self: _('New'))
    employee = fields.Many2one('hr.employee', string="Employee", related="imprest_ids.given_to")
    amount = fields.Monetary(string="Amount", related="imprest_ids.amount")
    date = fields.Date(string="Date", related="imprest_ids.date")
    month = fields.Char(string="Month")
    year = fields.Char(string="Year")
    currency_id = fields.Many2one('res.currency', 'Currency', required=True,
                                  default=lambda self: self.env.company.currency_id.id)
    analytic_acct = fields.Many2one("account.analytic.account", string="Analytic Account")
    date_given = fields.Date(string="Date Given")
    start_date = fields.Date(string="Start Date", default=fields.Date.today())
    end_date = fields.Date(string="End Date")
    duration = fields.Integer(string="Duration")
    warn_ing = fields.Boolean(default=False)
    state = fields.Selection([
        ('new', 'New'),
        ('in_progress', 'In Progress'),
        ('done', 'Done'),
    ], string='Status', readonly=True, index=True, copy=False, default='new', tracking=True)
    imprest_ids = fields.One2many('imprest.lines', 'imprest_id', string="Imprest Line Items")


class ImprestLines(models.Model):
    _name = "imprest.lines"

    given_to = fields.Many2one('hr.employee', string="Employee")
    description = fields.Char(string="Description")
    amount = fields.Monetary(string="Amount")
    date = fields.Date(string="Date")
    currency_id = fields.Many2one('res.currency', 'Currency', required=True,
                                  default=lambda self: self.env.company.currency_id.id)
    imprest_id = fields.Many2one('imprest.handler', string="Imprest ID")


class CashRequest(models.Model):
    _name = "cash.request"
    _rec_name = 'name_seq'

    @api.model
    def read_group(self, domain, fields, groupby, offset=0, limit=None, orderby=False, lazy=True):
        res = super(CashRequest, self).read_group(domain, fields, groupby, offset=offset, limit=limit,
                                                  orderby=orderby, lazy=lazy)
        if 'amount' in fields:
            for line in res:
                if '__domain' in line:
                    lines = self.search(line['__domain'])
                    amount = 0.0
                    for record in lines:
                        amount += record.amount
                    line['amount'] = amount
        return res

    @api.model
    def create(self, vals):
        if vals.get('name_seq', _('New')) == _('New'):
            vals['name_seq'] = self.env['ir.sequence'].next_by_code('cashrequest.sequence') or _('New')
        result = super(CashRequest, self).create(vals)
        return result

    @api.onchange('request_date')
    def change_date_field_year(self):
        self.year = fields.Date.from_string(self.request_date).strftime('%Y')
        print(self.year)

    @api.onchange('request_date')
    def change_date_field(self):
        self.month = fields.Date.from_string(self.request_date).strftime('%m')
        if self.month == '01':
            self.month = 'January'
        elif self.month == '02':
            self.month = 'Feburary'
        elif self.month == '03':
            self.month = 'March'
        elif self.month == '04':
            self.month = 'April'
        elif self.month == '05':
            self.month = 'May'
        elif self.month == '06':
            self.month = 'June'
        elif self.month == '07':
            self.month = 'July'
        elif self.month == '08':
            self.month = 'August'
        elif self.month == '09':
            self.month = 'September'
        elif self.month == '10':
            self.month = 'October'
        elif self.month == '11':
            self.month = 'November'
        else:
            self.month = 'December'

    def action_submit(self):
        self.write({'state': 'submitted'})

    def action_approve(self):
        self.write({'state': 'approved'})

    def action_paid(self):
        self.write({'state': 'paid'})

    title = fields.Char(string="Title")
    employee = fields.Many2one('hr.employee', string="Employee")
    location = fields.Char(string="Location")
    department = fields.Many2one('hr.department', string="Department")
    month = fields.Char(string="Month")
    year = fields.Char(string="Year")
    name_seq = fields.Char(string='Request Reference', required=True, copy=False, readonly=True,
                           index=True, default=lambda self: _('New'))
    job_position = fields.Many2one('hr.job', string="Job Position")
    request_date = fields.Date(string="Request Date", default=fields.Date.today())
    amount = fields.Monetary(string="Amount", related="request_ids.amount")
    currency_id = fields.Many2one('res.currency', 'Currency', required=True,
                                  default=lambda self: self.env.company.currency_id.id)
    state = fields.Selection([
        ('new', 'New'),
        ('submitted', 'Submitted'),
        ('approved', 'Approved'),
        ('paid', 'Paid'),
    ], string='Status', readonly=True, index=True, copy=False, default='new', tracking=True)
    request_ids = fields.One2many('request.lines', 'request_id', string="Request Line Items")


class CashRequestLines(models.Model):
    _name = "request.lines"

    description = fields.Text(string="Description")
    currency_id = fields.Many2one('res.currency', 'Currency', required=True,
                                  default=lambda self: self.env.company.currency_id.id)
    amount = fields.Monetary(string="Amount", compute="_total_amount",)
    product = fields.Many2one('product.product', string="Product")
    unit_price = fields.Monetary(string="Unit Price")
    qty = fields.Integer(string="Quantity")
    request_id = fields.Many2one('cash.request', string="Request ID")

    @api.depends('qty', 'unit_price')
    def _total_amount(self):
        for rec in self:
            if rec.qty >= 1:
                rec.amount = rec.qty * rec.unit_price
            else:
                rec.amount = rec.unit_price




