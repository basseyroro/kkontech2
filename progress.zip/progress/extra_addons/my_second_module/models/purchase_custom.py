from odoo import models, fields, api, _


class PurchaseCustom(models.Model):
    _inherit = 'purchase.order'

    def acct_approve(self):
        self.write({'state': 'approved'})
        return {}

    def button_confirm(self):
        for order in self:
            if order.state not in ['draft', 'approved']:
                continue
            order._add_supplier_to_product()
            # Deal with double validation process
            if order._approval_allowed():
                order.button_approve()
            else:
                order.write({'state': 'to approve'})
            if order.partner_id not in order.message_partner_ids:
                order.message_subscribe([order.partner_id.id])
        return True

    state = fields.Selection([
        ('draft', 'RFQ'),
        ('sent', 'RFQ Sent'),
        ('approved', 'Approved'),
        ('to approve', 'To Approve'),
        ('purchase', 'Purchase Order'),
        ('done', 'Locked'),
        ('cancel', 'Cancelled')],
        string='Status', readonly=True, index=True, copy=False, default='draft', tracking=True)

