from odoo import api, fields, models, _


class CreateJobCostWizard(models.TransientModel):
    _name = "create.jobcost.wizard"
    _description = "Job Cost Sheet"
    _inherit = ['mail.thread', 'mail.activity.mixin']

    def create_job_cost(self):
        vals = {
            'job_order': self.job_order.id,
            'project': self.project.id,
        }
        job_cost_rec = self.env['job.cost'].create(vals)
        return {
            'name': _('Job Cost'),
            'type': 'ir.actions.act_window',
            'view_mode': 'form',
            'res_model': 'job.cost',
            'res_id': job_cost_rec.id,
            'target': 'new',

        }

    title = fields.Many2one('job.order.lines', string="Title")
    project = fields.Many2one('project.project', string="Project")
    job_order = fields.Many2one('job.costing', string="Job Order")
    analytic_acct = fields.Many2one("account.analytic.account", string="Analytic Account")
    user_id = fields.Many2one('res.users', string='Created By', default=lambda self: self.env.user)
    total_amt = fields.Integer(compute="_total_all", string="Total")
    mat_lines = fields.One2many('material.cost', 'mat_id', string="Material Lines")
    lab_lines = fields.One2many('labour.cost', 'lab_id', string="Labour Lines")
    equip_lines = fields.One2many('equipment.cost', 'equip_id', string="Equipment Lines")
    overhead_lines = fields.One2many('overhead.cost', 'overhead_id', string="overhead Lines")

    @api.depends('mat_lines.amount')
    def _total_all(self):
        for order in self:
            total_amt = 0.0
            for line in order.mat_lines:
                total_amt += line.amount


class Material(models.TransientModel):
    _name = "material.cost"

    product = fields.Many2one('product.product', string="Material")
    uom = fields.Many2one('uom.uom', string="Unit of Measure")
    description = fields.Char(string="Description")
    unit_price = fields.Monetary(string="Unit Price")
    quantity = fields.Integer(string="Quantity")
    currency_id = fields.Many2one('res.currency', 'Currency', required=True,
                                  default=lambda self: self.env.company.currency_id.id)
    amount = fields.Monetary(compute="_total_amount", string="Amount")
    display_type = fields.Selection([
        ('line_section', "Section"),
        ('line_note', "Note")], default=False)
    mat_id = fields.Many2one('create.jobcost.wizard', string="Order ID")

    @api.depends('quantity', 'unit_price')
    def _total_amount(self):
        for rec in self:
            rec.amount = rec.quantity * rec.unit_price


class Labour(models.TransientModel):
    _name = "labour.cost"

    employee = fields.Many2one('hr.employee', string="Employee")
    dept = fields.Many2one('hr.department', string="Department")
    job = fields.Many2one('hr.job', string="Job Position")
    currency_id = fields.Many2one('res.currency', 'Currency', required=True,
                                  default=lambda self: self.env.company.currency_id.id)
    cost_day = fields.Monetary(string="Rate")
    estimated_cost = fields.Monetary(compute='_estimated_cost', string="Total")
    estimated_days = fields.Integer(string="No of Days")
    display_type = fields.Selection([
        ('line_section', "Section"),
        ('line_note', "Note")], default=False)
    lab_id = fields.Many2one('create.jobcost.wizard', string="Order ID")

    @api.depends('cost_day', 'estimated_days')
    def _estimated_cost(self):
        for rec in self:
            rec.estimated_cost = rec.estimated_days * rec.cost_day


class Equipment(models.TransientModel):
    _name = "equipment.cost"

    equipment = fields.Many2one('maintenance.equipment', string="Equipment")
    equip_category = fields.Many2one('maintenance.equipment.category', string="Equipment Category")
    currency_id = fields.Many2one('res.currency', 'Currency', required=True,
                                  default=lambda self: self.env.company.currency_id.id)
    cost_day = fields.Monetary(string="Rate")
    estimated_cost = fields.Monetary(compute='_estimated_amount', string="Total")
    estimated_days = fields.Integer(string="No of Days")
    display_type = fields.Selection([
        ('line_section', "Section"),
        ('line_note', "Note")], default=False)
    equip_id = fields.Many2one('create.jobcost.wizard', string="Order ID")

    @api.depends('cost_day', 'estimated_days')
    def _estimated_amount(self):
        for rec in self:
            rec.estimated_cost = rec.cost_day * rec.estimated_days


class Overhead(models.TransientModel):
    _name = "overhead.cost"

    expense = fields.Char(string="Expense")
    currency_id = fields.Many2one('res.currency', 'Currency', required=True,
                                  default=lambda self: self.env.company.currency_id.id)
    unit_price = fields.Monetary(string="Unit Price")
    estimated_cost = fields.Monetary(string="Total", compute="_estimated_amount")
    quantity = fields.Integer(string="Quantity")
    display_type = fields.Selection([
        ('line_section', "Section"),
        ('line_note', "Note")], default=False)
    overhead_id = fields.Many2one('create.jobcost.wizard', string="Order ID")

    @api.depends('unit_price', 'quantity')
    def _estimated_amount(self):
        for rec in self:
            rec.estimated_cost = rec.unit_price * rec.quantity







