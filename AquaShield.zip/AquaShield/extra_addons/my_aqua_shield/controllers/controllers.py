# -*- coding: utf-8 -*-
# from odoo import http


# class MyAquaShield(http.Controller):
#     @http.route('/my_aqua_shield/my_aqua_shield/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/my_aqua_shield/my_aqua_shield/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('my_aqua_shield.listing', {
#             'root': '/my_aqua_shield/my_aqua_shield',
#             'objects': http.request.env['my_aqua_shield.my_aqua_shield'].search([]),
#         })

#     @http.route('/my_aqua_shield/my_aqua_shield/objects/<model("my_aqua_shield.my_aqua_shield"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('my_aqua_shield.object', {
#             'object': obj
#         })
